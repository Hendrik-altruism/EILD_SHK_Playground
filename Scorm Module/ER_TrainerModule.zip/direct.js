//Initialisierung des WebDAV Clients, der Datenbank und der Intervallfunktion
var client
var tag;

//Nutzer loggt sich mit seinen LEA Daten ein
async function login() {
    initCon(document.getElementById("StudData"), document.getElementById("StudPw"))
    tag = document.getElementById("StudData").value
    document.querySelector(".popup").style.display = "none";
}

//Verbindung zum LEA WebDAV Client wird hergestellt
function initCon(User, Pw) {
    client = window.WebDAV.createClient("https://lea.hochschule-bonn-rhein-sieg.de/webdav.php/db_040811/ref_1209729/", {
        authType: window.WebDAV.AuthType.Digest,
        maxContentLength: 1000000,
        username: User,
        password: Pw
    });
    progressCallback()
}
function progressCallback() {
    console.log("done");
}

//Datenbank Funktionen
//Fügt einen Eintrag in die Datenbank hinzu
async function addRun() {
    var lock = await client.getFileContents("/lock.txt", { format: "text" })
    if (lock.charAt(0) == "1") {
        var i = 0
        do {
            sleep(100)
            i + 1
            lock = await client.getFileContents("/lock.txt", { format: "text" })
        }
        while (lock.charAt(0) == "1" && i < 5)
    }
    client.putFileContents("/lock.txt", "1" + lock.substr(1))
    const run = {
        studTag: document.getElementById("InputStudID").value,
        points: document.getElementById("InputPoints").value
    }
    console.log("exec")
    const data = (await client.getFileContents("/data.json", { format: "text" })).concat(run)
    console.log(data)
    client.putFileContents("/data.json", file)
    clearInput()
}

//Setzt die Datenbank zurück
async function clearRun() {
    const idbDatabase = db.backendDB()
    try {
        await clearDatabase(idbDatabase, function (err) { })
    }
    catch (error) {
        console.error('' + error);
    }
    updateFile()
    showContent()
}

//Klärt die Input Felder
function clearInput() {
    document.getElementById("RunID").value = ""
    document.getElementById("InputStudID").value = ""
    document.getElementById("InputPoints").value = ""
}

//Promises
function sleep(ms) {
    return new Promise(resolve => setTimeout(resolve, ms));
}