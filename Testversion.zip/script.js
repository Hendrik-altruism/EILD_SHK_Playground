
const client = window.WebDAV.createClient("https://lea.hochschule-bonn-rhein-sieg.de/webdav.php/db_040811/ref_1209729/", {
    authType: window.WebDAV.AuthType.Digest,
    maxContentLength: 100000000,
    username: "houde2s",
    password: "060501"
});

//const directoryItems = await client.getDirectoryContents("/");
client.putFileContents("/lost.txt", "hahaha");


//Initialize DB
var db = new Dexie("indexedDataBase")
db.version(1).stores({
    runs: "++id, studTag, points"
})
showContent().catch(err => console.error('' + err));

//Datenbank Funktionen
//fügt einen Eintrag in die Datenbank hinzu
async function addRun() {
    await db.runs.add(
        { studTag: document.getElementById("InputStudID").value, points: document.getElementById("InputPoints").value }
    )
    showContent().catch(err => console.error('' + err));
    clearInput()
}

//löscht einen Eintrag nach der eingegeben ID
async function deleteRun() {
    await db.runs.delete(parseInt(document.getElementById("RunID").value))
    showContent().catch(err => console.error('' + err));
    clearInput()
}

//löscht einen Eintrag durch Click in der Tabelle
async function deleteRunExtra(param) {
    await db.runs.delete(parseInt(param))
    showContent().catch(err => console.error('' + err));
}

//Ändert einen Eintrag nach der ID
async function updateRun() {
    await db.runs.update(
        parseInt(document.getElementById("RunID").value), { studTag: document.getElementById("InputStudID").value, points: document.getElementById("InputPoints").value }
    )
    showContent().catch(err => console.error('' + err));
    clearInput()
}

//Fügt den Eintrag in die Felder zur Bearbeitung
async function updateExtra(param) {
    var run = await db.runs.get(parseInt(param))
    document.getElementById("RunID").value = run.id
    document.getElementById("InputStudID").value = run.studTag
    document.getElementById("InputPoints").value = run.points
}

//Setzt die Datenbank zurück
async function clearRun() {
    await db.delete()
    document.location.reload()
    showContent().catch(err => console.error('' + err));
    clearInput()
}

//Klärt die Input Felder
function clearInput() {
    document.getElementById("RunID").value = ""
    document.getElementById("InputStudID").value = ""
    document.getElementById("InputPoints").value = ""
}

//Import<->Export
document.addEventListener('DOMContentLoaded', () => {
    showContent().catch(err => console.error('' + err));
    const dropZoneDiv = document.getElementById('dropzone');
    const exportLink = document.getElementById('exportLink');

    // Configure exportLink
    exportLink.onclick = async () => {
        try {
            const blob = await db.export({ prettyJson: true, progressCallback });
            download(blob, "dexie-export.json", "application/json");
        } catch (error) {
            console.error('' + error);
        }
    };


    // Configure dropZoneDiv
    dropZoneDiv.ondragover = event => {
        event.stopPropagation();
        event.preventDefault();
        event.dataTransfer.dropEffect = 'copy';
    };

    // Handle file drop:
    dropZoneDiv.ondrop = async ev => {
        ev.stopPropagation();
        ev.preventDefault();

        // Pick the File from the drop event (a File is also a Blob):
        const file = ev.dataTransfer.files[0];
        try {
            if (!file) throw new Error(`Only files can be dropped here`);
            console.log("Importing " + file.name);
            await db.delete();
            db = await Dexie.import(file, {
                progressCallback
            });
            console.log("Import complete");
            await showContent();
        } catch (error) {
            console.error('' + error);
        }
    }
});

function progressCallback({ totalRows, completedRows }) {
    console.log(`Progress: ${completedRows} of ${totalRows} rows completed`);
}


//Anzeigen der Daten
async function showContent() {
    const tbody = document.getElementsByTagName('tbody')[0];

    var s = '<table cellpadding="2" cellspacing="2" border="1">';
    s += '<tr><th>RunId</th><th>StudentenTag</th><th>Punkte</th></tr>'
    var n = await db.runs.count()

    for (var i = 1; i <= n; i++) {
        var run = await db.runs.get(i);
        if (run == undefined) {
            n++;
        } else {
            s += '<tr>';
            s += '<td>' + run.id + '</td>';
            s += '<td>' + run.studTag + '</td>';
            s += '<td>' + run.points + '</td>';
            s += '<td><a href="#" onclick="deleteRunExtra(' + run.id + ')">Löschen</a> | <a href="#" onclick="updateExtra(' + run.id + ')">Ändern</a></td>';
            s += '</tr>';
        }
    }
    s += '</table>';
    tbody.innerHTML = s
}
