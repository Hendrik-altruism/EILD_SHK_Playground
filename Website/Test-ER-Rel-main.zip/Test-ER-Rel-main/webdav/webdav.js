
window.webdav = true;
let phrases
let tag;
let client;
let studData = []
let collection
let pos = 0
const span = 25;
let tablePos = 0;
const tableSpan = 10;
let total = 0;
let graphSetting = false
const keys = new Array();
const right = new Array();
const wrong = new Array();
const testData = [{"correct":false,"key":"Paketdienstleister_DHL_Hermes_DPD_p_d"},{"correct":false,"key":"Musikstück_Komponist_1_n"},{"correct":false,"key":"Bürger_Wohnsitz_cn_n"},{"correct":false,"key":"Ordner_Ordner_c_cn"},{"correct":true,"key":"Patient_Patientenakte_1_1"},{"correct":true,"key":"Person_Besucher_Patient_Personal_t_n"},{"correct":true,"key":"X-Chromosom_Y-Chromosom_c_c"},{"correct":false,"key":"Haus_Eigentümer_n_n"},{"correct":true,"key":"Haustier_Hund_Katze_p_d"},{"correct":true,"key":"Verein_Kontaktperson_1_n"},{"correct":true,"key":"Mitarbeiter_Aufgabe_cn_c"},{"correct":true,"key":"Atom_Elektron_n_n"},{"correct":true,"key":"Weibchen_Männchen_c_c"},{"correct":true,"key":"Gebäude_Raum_n_1"},{"correct":false,"key":"Firma_Auftrag_cn_1"},{"correct":true,"key":"Bewohner_Haus_1_cn"},{"correct":true,"key":"App_Kategorie_n_cn"},{"correct":true,"key":"Atom_Atomkern_1_1"},{"correct":true,"key":"Hund_Schäferhund_Mops_Dackel_p_n"},{"correct":true,"key":"Paketdienstleister_DHL_Hermes_DPD_p_d"},{"correct":true,"key":"Hochschulangehöriger_Student_Mitarbeiter_t_n"},{"correct":true,"key":"Rezept_Zutat_n_cn"},{"correct":true,"key":"Student_Professor_Lehrveranstaltung_cn_cn_cn"},{"correct":true,"key":"Topf_Deckel_c_1"},{"correct":true,"key":"Elternteil_Mutter_Vater_t_d"},{"correct":true,"key":"Bürger_Wohnsitz_cn_n"},{"correct":true,"key":"Pilot_Flugzeug_Flugroute_cn_cn_n"},{"correct":true,"key":"Bürger_Partei_c_n"},{"correct":true,"key":"Kunde_Produkt_cn_cn"}]
createPopup()

async function setPhrases(p){
  phrases = p
}

async function createPopup(){
    let m = `
  <div class="modal show" id="myModal" tabindex="-1" role="dialog" aria-labelledby="exampleModalLabel" aria-hidden="true" style="display: block;overflow: auto">
    <div class="modal-dialog" role="document">
      <div class="modal-content">
        <div class="modal-header">
          <h5 class="modal-title" id="exampleModalLabel">Nutzer Login</h5>
        </div>
        <div class="modal-body">
        <div class="form-group">
        <label for="exampleInputEmail1">Studenten Tag</label>
        <input type="text" class="form-control" id="StudData" aria-describedby="emailHelp" placeholder="LEA-Kürzel">
      </div>
      <div class="form-group">
        <label for="exampleInputPassword1">Password</label>
        <input type="password" class="form-control" id="StudPw" placeholder="MIA Password (LEA)">
      </div>
      <div class="form-check">
            <p id="errorMessage" style="color: red;display: none">StudentenTag oder Passwort falsch!</p>
        </div>
        </div>
        <div class="modal-footer">
        <button class="btn btn-primary" onclick="login()">Login</button>
        </div>
      </div>
    </div>
  </div>
  <div class="modal-backdrop show"></div>
  <link rel="stylesheet" href="https://cdn.jsdelivr.net/npm/bootstrap@4.0.0/dist/css/bootstrap.min.css" integrity="sha384-Gn5384xqQ1aoWXA+058RXPxPg6fy4IWvTNh0E263XmFcJlSAwiGgFAW/dAiS6JXm" crossorigin="anonymous">
  `
    document.getElementById("er_rel_trainer-1").insertAdjacentHTML("afterend", m)
}

async function userDataPlot(){
    document.getElementById("myModal").innerHTML = ''
    let dataPop = `
    <div class="modal-dialog" role="document" style="min-width:500px;max-width:1000px">
      <div class="modal-content">
        <div class="modal-header">
          <h5 class="modal-title" id="dataHeader">Ergebnisshistorie</h5>
          <button class="btn btn-primary" onclick="toggleDataModal()">Bearbeitung fortsetzen</button>
        </div>
        <div class="modal-body">
        </div>
      </div>
    </div>
    `
    document.getElementById("myModal").innerHTML = dataPop;
}

//User login with his student data to allow WebDAV access to the script 
async function login() {
    tag = hash(document.getElementById("StudData").value)
    try{
        initCon(document.getElementById("StudData"), document.getElementById("StudPw"))  
        call();
    }
    catch(err){
        document.getElementById("errorMessage").style.display = "block";
        document.getElementById("StudPw").value="";
        return false;
    }
    document.querySelector("#myModal").style.display = "none";     
    document.querySelector(".modal-backdrop").style.display = "none";  
    userDataPlot()                                                                    
    return true;
}
//Intialization of the user Connection with console log aon completion
function initCon(User, Pw) {
    try{
    client = window.WebDAV.createClient("https://lea.hochschule-bonn-rhein-sieg.de/webdav.php/db_040811/ref_1325238/", {
        authType: window.WebDAV.AuthType.Digest,
        maxContentLength: 1000000,
        username: User,
        password: Pw
    });
    }catch(err){
        return err;
    }
    return client;
}


//Scans for existing User directory and creates it, if needed
async function call() {
    try { await client.getFileContents("/" + tag + ".json", { format: "text" }) }
    catch (e) {
        console.log("User Directory needs to be created")
        data = "[]"
        client.putFileContents("/" + tag + ".json", data)
    }
}

//checks if phrases in default are on actual state   

//Inserts the Run into the Json File
async function insertRun(file) {
    if(file.results[file.results.length-2].hasOwnProperty('correct')){
        const run = {
            correct: file.results[file.results.length-2].correct,
            key: file.phrases[file.results.length-2].key,
        }
        let data = JSON.parse(await client.getFileContents("/" + tag + ".json", { format: "text" }))    
        data.push(run)
        try{
            client.putFileContents("/" + tag + ".json", JSON.stringify(data))       
        } catch(error){
        }
    }               
}

//Sleep function -> stop the script in case of a lock
function sleep(ms) {
    return new Promise(resolve => setTimeout(resolve, ms));
}

//Einfache Hashfunktion
function hash(s) {
    var a = 1, c = 0, h, o;
    if (s) {
        a = 0;
        for (h = s.length - 1; h >= 0; h--) {
            o = s.charCodeAt(h);
            a = (a << 6 & 268435455) + o + (o << 14);
            c = a & 266338304;
            a = c !== 0 ? a ^ c >> 21 : a;
        }
    }
    return String(a);
};


async function toggleDataModal(){
    const myModal = document.querySelector('#myModal')
    const trainer = document.querySelector('body')
    if(myModal.style.display === "none"){
        myModal.querySelector('.modal-body').innerHTML = await generateGraphTemplate();
        await fillTemplate()
        myModal.style.display = "block";
        trainer.style.overflow = "hidden";
        document.querySelector('.modal-backdrop').style.display = "block";
    }else{
        myModal.querySelector('.modal-body').innerHTML = '';
        myModal.style.display = "none";
        document.querySelector('.modal-backdrop').style.display = "none";
        trainer.style.overflow = "auto";
    }
}

async function generateGraphTemplate(){
  let htmlData = `
<div class="customContainer">
    <div class="row" id="tableBox">
        <table id="dataTable" class="table table-striped borderBox">
          <thead>
              <tr>
                  <th>Phrase</th>
                  <th>Ergebniss</th>
              </tr>
          </thead>
          <tbody id="tbody">
          </tbody>
        </table>
        <div class="phraseContent borderBox">
            <div class="desHeader">
                <b>Beschreibung</b>
            </div>
            <div id="phraseContentDes">
            </div>
        </div>
    </div>
</div>
<div class="container controller" id="tableController">
  <p id="totalAmount"></p>
  <ul class="pagination">
      <li id="prevTable" class="paginate_button page-item previous disabled" id="">
          <a onclick="changePreviousTable()" href="#" class="page-link">Vorherige</a>
      </li>
      <li id="routeTable" class="paginate_button page-item active">
          <a class="page-link">0 bis 10</a>
      </li>
      <li id="nextTable" class="paginate_button page-item previous disabled" id="">
          <a onclick="changeNextTable()" href="#" class="page-link">Nächste</a>
      </li>
  </ul>
</div>
<div>
  <div id="graph1">
  </div>
</div>
<div class="container controller" id="chartsController">
  <button class="btn btn-primary" id="switchGraphMode" onclick="toggleGraphSetting()">Prozent</button>
  <ul class="pagination">
      <li id="prev" class="paginate_button page-item previous disabled" id="">
          <a onclick="changePrevious()" href="#" class="page-link">Vorherige</a>
      </li>
      <li id="route" class="paginate_button page-item active">
          <a class="page-link">0 bis 25</a>
      </li>
      <li id="next" class="paginate_button page-item previous disabled" id="">
          <a onclick="changeNext()" href="#" class="page-link">Nächste</a>
      </li>
  </ul>
</div>
<style>
    .customContainer{
        padding: 0 1.5em;
    }

    .tableLinks {
      color: black;
  }
  
  div.column {
      float: left;
      margin: 12px;
      border: 2px solid #bbb;
      border-radius: 10px;
      padding: 10px;
  }
  
  #InputField {
      margin: 12;
  }
   
  #tableBox{
    display: flex;
    margin-bottom: 20px;
  }

  #dataTable{
    width: 60%;
    margin: 0;
  }
  
  .borderBox{
    border: 1px solid rgba(0, 0, 0, .1);
    border-radius: 2px;
  }

  .desHeader{
    padding: 12px 1em;
    border-width: 0px 0px 2px 0px;
    border-style: solid;
    border-color: rgba(0, 0, 0, .1);
  }

  #phraseContentDes{
      padding: 1em;
  }

  .phraseContent{
      width: 40%;
  }

  table {
      text-align: left;
  }
  
  
  #headline{
      font-size: 25px;
      font-weight: 550;
  }

  .contentUser {
      display: flex;
      flex-wrap: wrap;
      justify-content: space-between;
  }
  
  .identifier {
      display: block;
      font-weight: 550;
      margin-bottom: 1px;
  }
  
  .dataField {
      width: calc(100%/2 -20px);
  }
  
  .variable {
      width: 100%;
      margin-bottom: 10px;
  }

  .modal-footer button{
    margin: 20px auto;
    padding: 8px;
  }

  ul.pagination{
      margin: 0;
  }
  
  #tablePhrase {
      display: block;
  }
  
  #graph1 {
      height: 400px;
      margin-bottom: 1em; 
  }
  
  .button-container{
      padding: 10px;
      display: flex;
      justify-content: center;
      align-items: center;
  }

  .highcharts-figure,
  .highcharts-data-table table {
      min-width: 310px;
      max-width: 800px;
      margin: 1em auto;
  }
  
  .highcharts-data-table table {
      font-family: Verdana, sans-serif;
      border-collapse: collapse;
      border: 1px solid #ebebeb;
      margin: 10px auto;
      text-align: center;
      width: 100%;
      max-width: 500px;
  }
  
  .highcharts-data-table caption {
      padding: 1em 0;
      font-size: 1.2em;
      color: #555;
  }
  
  .highcharts-data-table th {
      font-weight: 600;
      padding: 0.5em;
  }
  
  .highcharts-data-table td,
  .highcharts-data-table th,
  .highcharts-data-table caption {
      padding: 0.5em;
  }
  
  .highcharts-data-table thead tr,
  .highcharts-data-table tr:nth-child(even) {
      background: #f8f8f8;
  }
  
  .highcharts-data-table tr:hover {
      background: #f1f7ff;
  }
  
  .highcharts-column-series {
      cursor: pointer;
  }
  
  .controller {
      display: flex;
      justify-content: space-between;
      margin-bottom: 20px;
  }
  
    </style>
    <script src="valueCollection/resources/dataTables.bootstrap5.min.js"></script>
    <script src="valueCollection/resources/bootstrap.bundle.min.js"></script>

    <script src="valueCollection/resources/highcharts.js"></script>
    <script src="https://code.highcharts.com/modules/exporting.js"></script>
    <script src="https://code.highcharts.com/modules/export-data.js"></script>`
    return htmlData;
}

async function fillTemplate(){
  await getUpdatedSingle()
  await showContent(0)
}

async function getUpdatedAll() {
  for(i = 1; i<=phrases.length; i++){
    keys[i-1]=i
    right[i-1]=0
    wrong[i-1]=0
    }
  const directoryItems = await client.getDirectoryContents("/")
  studData.length = directoryItems.length-1
  for (let i = 1; i < directoryItems.length; i++) {
      var tempName = directoryItems[i].filename
      var tempData = await client.getFileContents("/" + tempName, { format: "text" });
      tempData = JSON.parse(tempData)
      try {
          for(let i = 0; i<tempData.length; i++){
              tempData[i].key = decript(tempData[i].key)
              tempData[i].correct ? right[tempData[i].key-1]+=1 : wrong[tempData[i].key-1]+=1;
          }
      } catch (error) {
      }
      studData[i-1]=tempData
  }
  createChart(0)
  createShown(pos, span)
  if(pos+span<keys.length){document.getElementById("next").classList.remove('disabled')}
  return true
}

async function getUpdatedSingle() {
  for(i = 1; i<=phrases.length; i++){
      keys[i-1]=i
      right[i-1]=0
      wrong[i-1]=0
    }
      let tempData = await client.getFileContents("/" + tag + ".json", { format: "text" });
      tempData = JSON.parse(tempData)
      //Test für example Data
      //let tempData = testData
      try {
          for(let i = 0; i<tempData.length; i++){
              tempData[i].key = decript(tempData[i].key)
              tempData[i].correct ? right[tempData[i].key-1]+=1 : wrong[tempData[i].key-1]+=1;
          }
      } catch (error) {
  }
  studData[0] = tempData
  createChart(0)
  createShown(pos, span)
  if(pos+span<keys.length){document.getElementById("next").classList.remove('disabled')}
  return true
}

async function showContent(outputSpan) {
  const tbody = document.getElementsByTagName('tbody')[0];
  tbody.innerHTML='';
  let totalRuns = []
  for (let i = 0; i < studData.length; i++) {
      const aktRuns = studData[i];
      for(let j = 0; j<aktRuns.length;j++){
          totalRuns.push(aktRuns[j])
      }
  }
  for (let y = outputSpan; y<totalRuns.length&&y<outputSpan+tableSpan; y++){
        const tableRow = document.createElement("tr")
        const run = totalRuns[y]
        const decKey = run.key-1
        const s = `
        <td><a href="javascript:callPopup(${decKey})" class="tableLinks">${run.key}</a></td>
        <td>${run.correct}</td>
        `
        tableRow.innerHTML = s;
        tbody.appendChild(tableRow)
}  
  tablePos = outputSpan
  total = totalRuns.length;
  document.querySelector('#totalAmount').innerHTML=`<b>Insgesamt ${total} Einträge</b>`
  createShownTable(tablePos, tableSpan)
  if((tablePos+tableSpan)<total){document.getElementById("nextTable").classList.remove('disabled')}
}

//Create Values for Chart to be plotted
async function createChart(outputSpan){
kArray = new Array();
rArray = new Array();
wArray = new Array();
for(i = outputSpan; i<outputSpan+span&&i<phrases.length; i++){
  kArray[i-outputSpan]=i+1
  rArray[i-outputSpan]=right[i]
  wArray[i-outputSpan]=wrong[i]
} 
plotChart(kArray, rArray, wArray) 
pos = outputSpan 
}

//Navigation Functions for the Table
async function changeNextTable(){
    if( !document.getElementById("nextTable").classList.contains('disabled')){
      showContent(tablePos+tableSpan)
      document.getElementById("prevTable").classList.remove('disabled')
      if(tablePos+tableSpan>=total){document.getElementById("nextTable").classList.add('disabled')}
      createShownTable(tablePos, tableSpan)
    }
}
    
async function changePreviousTable(){
    if(!document.getElementById("prevTable").classList.contains('disabled')){
      showContent(tablePos-tableSpan)
      document.getElementById("nextTable").classList.remove('disabled')
    if(tablePos-tableSpan<0){document.getElementById("prevTable").classList.add('disabled')}
      createShownTable(tablePos, tableSpan)
    }
}

async function createShownTable(akt, range){
    const shown = document.getElementById('routeTable')
    shown.innerHTML = '<a class="page-link">'+(akt+1)+" bis "+Math.min((akt+range), total)+'</a>'
}

//Graph Einstellung Button
async function toggleGraphSetting(){
    graphSetting = !graphSetting;
    if(graphSetting){
        document.getElementById("switchGraphMode").innerHTML = "Total"
    }else{
        document.getElementById("switchGraphMode").innerHTML = "Prozent"
    }
    createChart(pos)
}

//Navigation Functions for the Highcharts Plot
async function changeNext(){
if( !document.getElementById("next").classList.contains('disabled')){
  createChart(pos+span)
  document.getElementById("prev").classList.remove('disabled')
  if(pos+span>=keys.length){document.getElementById("next").classList.add('disabled')}
  createShown(pos, span)
}

}
async function changePrevious(){
 if(!document.getElementById("prev").classList.contains('disabled')){
  createChart(pos-span)
  document.getElementById("next").classList.remove('disabled')
  if(pos-span<0){document.getElementById("prev").classList.add('disabled')}
  createShown(pos, span)
 }

}
async function createShown(akt, range){
const shown = document.getElementById('route')
shown.innerHTML = '<a class="page-link">'+(akt+1)+" bis "+Math.min((akt+range), phrases.length)+'</a>'
}



function decript(skey){
  if(typeof skey === "number"){
      return skey;
  }
  var alist = skey.split("_");
  let ent = [];
  let sol = [];
  for(let b = 0; b<alist.length;b++){
      if(alist[b].length>2){
          ent.push(alist[b])
      }else{
          sol.push(alist[b])
      }
  }
  var nkey=0
  for(let i=0;i<phrases.length;i++){
    if(phrases[i].entities.toString()===ent.toString()&&phrases[i].solution.toString()===sol.toString()){
      nkey=i+1
    }
  }
  return nkey;
}

//Highchart function to create the chart
function plotChart(keyArray, rightArray, wrongArray) {
    let stack = "normal"
    let yText = "Ergebnisse Total"
    if(graphSetting){
        stack = "percent"
        yText = 'Ergebnisse in Prozent'
    }

  Highcharts.chart('graph1', {
      chart: {
          type: 'column'
      },
      title: {
          text: 'Phrasen Ergebnisse'
      },
      xAxis: {
          categories: keyArray,
          labels: {
            
          }
      },
      yAxis: {
          min: 0,
          title: {
              text: `${yText}`
          }
      },
      tooltip: {
          pointFormat: '<span style="color:{series.color}">{series.name}</span>: <b>{point.y}</b> ({point.percentage:.0f}%)<br/>',
          shared: true
      },
      plotOptions: {
          column: {
              stacking: `${stack}`,
              events: {
                 click: function(oEvent){
                   callPopup(oEvent.point.x+pos)
                 }
              }
          }
      },
      series: [{
          name: 'Falsch beantwortet',
          data: wrongArray,
          color: 'red'
      }, {
          name: 'Richtig beantwortet',
          data: rightArray,
          color: 'green'
      },]
  });
}

//Function to call the popub window for Phrase information
function callPopup(phraseID){
document.querySelector('.desHeader').innerHTML = "<b>Beschreibung Phrase: "+ (phraseID+1)+ "</b>"
var phrase = phrases[phraseID]
var p = '<div class="DataField"><span class="identifier">Text: </span><span class="variable">'+phrase.text.toString()+'</span></div>'  
p+= '<div class="DataField"><span class="identifier">Entitäten: </span><span class="variable">'+phrase.entities.toString()+'</span></div>'
if(phrase.hasOwnProperty('relation')){
p+= '<div class="DataField"><span class="identifier">Relation: </span><span class="variable">'+phrase.relation.toString()+'</span></div>'
} else {
  p+= '<div class="DataField"><span class="identifier">Relation: </span><span class="variable">ist</span></div>'
}
p+= '<div class="DataField"><span class="identifier">Lösung: </span><span class="variable">'+phrase.solution.toString()+'</span></div>'
p+= '<div class="DataField"><span class="identifier">Kommentare: </span><span class="variable">'+phrase.comments.toString()+'</span></div>'
p+= '<div class="button-container"><button class="btn btn-primary phrase-btn">Phrase Bearbeiten</button></div>'
document.getElementById('phraseContentDes').innerHTML = p
document.querySelector('.phrase-btn').addEventListener('click', async ()=>{
    ccm.start(".../ccm.er_rel_trainer.js", {
        root: document.querySelector('.modal-body'),
        phrases: [phrase],
        html: [ "ccm.load", { "url": "./webdav/valueCollection/resources/custom.js", "type": "module" } ],
        onfinish: async (event, instance)=>{
            const result = instance.getValue();
            const phrase = result.phrases[0];
            
            phrase.key = phrase.entities.concat(phrase.solution).join('_');
            
            if(result.results[0].hasOwnProperty('correct')){
                const run = {
                    correct: result.results[0].correct,
                    key: phrase.key,
                }
                let data = JSON.parse(await client.getFileContents("/" + tag + ".json", { format: "text" }))    
                data.push(run)
                try{
                    client.putFileContents("/" + tag + ".json", JSON.stringify(data))       
                } catch(error){
                }
            } 

            document.querySelector('.modal-body').innerHTML = await generateGraphTemplate();
            await fillTemplate();
        }
    });
});
}

